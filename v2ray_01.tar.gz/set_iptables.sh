#!/bin/bash
# This scripts are used to set tproxy iptables, which should be run in root mode
# 
#  Usage:
#    tproxy_iptables.sh <remote_svr>
#      
#  Example:
#    tproxy_iptables.sh  47.168.1.2 "192.168.1.0/24, 10.10.0.0/16" 
#
#                       All rights reserved by mineros.cn @2021-2025
#    
#    Update history
#   --------------------------------------------------------------------------------------
#    v0.0.1  2021.11.25  Jesse Jiang   Init
#

##
IPT_REMOVE='0'
IPT_ADD='1'

IPT_ACTION=$1
REMOTE_V2RAY_SVR=$2
LAN_LIST=$3

flush_ipt() {
  # flush mangle table
  iptables -t mangle -F
  iptables -t mangle -P PREROUTING ACCEPT
  iptables -t mangle -P INPUT ACCEPT
  iptables -t mangle -P FORWARD ACCEPT
  iptables -t mangle -P OUTPUT ACCEPT
  iptables -t mangle -P POSTROUTING ACCEPT

  # flush nat table
  iptables -t nat -F
  iptables -t nat -P PREROUTING ACCEPT
  iptables -t nat -P INPUT ACCEPT
  iptables -t nat -P OUTPUT ACCEPT
  iptables -t nat -P POSTROUTING ACCEPT

  while true
  do
    if ! ip rule del table 100 > /dev/null 2>&1; then
      break
    fi
  done
  echo -e "\e[1;32m[ OK ]\e[0m: Success to remove TPROXY iptables! "
}

add_ipt() {
  # set route rule
  ip rule add fwmark 1 table 100
  ip route add local 0.0.0.0/0 dev lo table 100

  # add iptable logs
  #iptables -t mangle -A V2RAY -j LOG
  #iptables -t mangle -A V2RAY_MASK -j LOG

  # tproxy local network
  iptables -t mangle -N V2RAY
  # Ignore remote V2Ray server's addresses
  iptables -t mangle -A V2RAY -d  ${REMOTE_V2RAY_SVR}/32 -j RETURN
  # Ignore LANs and any other addresses you'd like to bypass the proxy
  # See Wikipedia and RFC5735 for full list of reserved networks.
  iptables -t mangle -A V2RAY -d 127.0.0.1/32 -j RETURN
  iptables -t mangle -A V2RAY -d 224.0.0.0/4 -j RETURN
  iptables -t mangle -A V2RAY -d 255.255.255.255/32 -j RETURN
  iptables -t mangle -A V2RAY -d 169.254.0.0/16 -j RETURN
  
  # iptables -t mangle -A V2RAY -d 10.10.1.0/24 -p tcp -j RETURN 
  # iptables -t mangle -A V2RAY -d 10.10.1.0/24 -p udp ! --dport 53 -j RETURN 
  IFS=', ' read -r -a arr_list <<< "$LAN_LIST"
  for subnet in "${arr_list[@]}"
  do
    iptables -t mangle -A V2RAY -d $subnet -p tcp -j RETURN 
    iptables -t mangle -A V2RAY -d $subnet -p udp ! --dport 53 -j RETURN 
  done

  iptables -t mangle -A V2RAY -j RETURN -m mark --mark 0xff 
  iptables -t mangle -A V2RAY -p udp -j TPROXY --on-port 22300 --tproxy-mark 1
  iptables -t mangle -A V2RAY -p tcp -j TPROXY --on-port 22300 --tproxy-mark 1
  iptables -t mangle -A PREROUTING -j V2RAY

  # tproxy host(gw) itself
  iptables -t mangle -N V2RAY_MASK
  # Ignore remote V2Ray server's addresses
  iptables -t mangle -A V2RAY_MASK -d  ${REMOTE_V2RAY_SVR}/32 -j RETURN
  iptables -t mangle -A V2RAY_MASK -d 224.0.0.0/4 -j RETURN
  iptables -t mangle -A V2RAY_MASK -d 255.255.255.255/32 -j RETURN
  iptables -t mangle -A V2RAY_MASK -d 169.254.0.0/16 -j RETURN

  # iptables -t mangle -A V2RAY_MASK -d 10.10.1.0/24 -p tcp -j RETURN 
  # iptables -t mangle -A V2RAY_MASK -d 10.10.1.0/24 -p udp ! --dport 53 -j RETURN
  IFS=', ' read -r -a arr_list <<< "$LAN_LIST"
  for subnet in "${arr_list[@]}"
  do
    iptables -t mangle -A V2RAY_MASK -d $subnet -p tcp -j RETURN 
    iptables -t mangle -A V2RAY_MASK -d $subnet -p udp ! --dport 53 -j RETURN 
  done

  iptables -t mangle -A V2RAY_MASK -j RETURN -m mark --mark 0xff 
  iptables -t mangle -A V2RAY_MASK -p udp -j MARK --set-mark 1 
  iptables -t mangle -A V2RAY_MASK -p tcp -j MARK --set-mark 1 
  iptables -t mangle -A OUTPUT -j V2RAY_MASK


  echo -e "\e[1;32m[ OK ]\e[0m: Success to set TPROXY iptables! "
}

## ---script---
flush_ipt
if [[ "$IPT_ACTION" -eq "$IPT_ADD" ]]; then
  add_ipt
fi

exit 0