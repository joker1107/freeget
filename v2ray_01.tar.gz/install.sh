#!/bin/bash
# shellcheck disable=SC2268

# The files installed by the script conform to the Filesystem Hierarchy Standard:
# https://wiki.linuxfoundation.org/lsb/fhs

# You can set this variable whatever you want in shell session right before running this script by issuing:
# export DAT_PATH='/usr/local/share/v2ray'
DAT_PATH=${DAT_PATH:-/usr/local/share/v2ray}

# You can set this variable whatever you want in shell session right before running this script by issuing:
# export JSON_PATH='/usr/local/etc/v2ray'
JSON_PATH=${JSON_PATH:-/usr/local/etc/v2ray}

# Set this variable only if you are starting v2ray with multiple configuration files:
# export JSONS_PATH='/usr/local/etc/v2ray'

# Set this variable only if you want this script to check all the systemd unit file:
# export check_all_service_files='yes'

##=========================  LOCAL VARIABLE  ==========================##
##
REMOVE_FLAG=
REINSTALL_FLAG=
LOCAL_FILE=v2ray-linux-64.zip
CLIENT_FLAG=
BLACK_LIST="\"domain:youtube.com\", \"domain:pornhub.com\", \"domain:facebook.com\",  \"domain:discord.com\",  \"domain:telegram.org\", \"domain:twitter.com\""

## 
# 0 - ERROR, 1 -WARN, 2 - INFO, 3 - DEBUG
LOG_LEVEL_ERROR=0
LOG_LEVEL_WARN=1
LOG_LEVEL_INFO=2
LOG_LEVEL_DEBUG=3
LOG_LEVEL=${LOG_LEVEL_DEBUG}
INS_LOG_PATH=/var/log/v2ray_install.log

##
IPT_REMOVE='0'
IPT_ADD='1'

##
ERR_OK=0
ERR_OS_NOT_SUPPORTED=1
ERR_NOT_ROOT=2
ERR_INVALID_PARAM=3
ERR_INSPKG_FAILURE=4
ERR_CORRUPT_FILE=5
ERR_OPER_SVC=6
ERR_RM_FILE=7
ERR_NOT_ALLOWED=8

##=========================  FUNCTIONS  ==========================##
##

check_if_running_as_root() {
  # If you want to run as another user, please modify $UID to be owned by this user
  if [[ "$UID" -ne '0' ]]; then
    echo "WARNING: The user currently executing this script is not root. You may encounter the insufficient privilege error."
    read -r -p "Are you sure you want to continue? [y/n] " cont_without_been_root
    if [[ x"${cont_without_been_root:0:1}" = x'y' ]]; then
      echo "Continuing the installation with current user..."
    else
      echo "Not running with root, exiting..."
      exit $ERR_NOT_ROOT
    fi
  fi
}


identify_the_operating_system_and_architecture() {
  if [[ "$(uname)" == 'Linux' ]]; then
    case "$(uname -m)" in
      'i386' | 'i686')
        MACHINE='32'
        ;;
      'amd64' | 'x86_64')
        MACHINE='64'
        ;;
      'armv5tel')
        MACHINE='arm32-v5'
        ;;
      'armv6l')
        MACHINE='arm32-v6'
        grep Features /proc/cpuinfo | grep -qw 'vfp' || MACHINE='arm32-v5'
        ;;
      'armv7' | 'armv7l')
        MACHINE='arm32-v7a'
        grep Features /proc/cpuinfo | grep -qw 'vfp' || MACHINE='arm32-v5'
        ;;
      'armv8' | 'aarch64')
        MACHINE='arm64-v8a'
        ;;
      'mips')
        MACHINE='mips32'
        ;;
      'mipsle')
        MACHINE='mips32le'
        ;;
      'mips64')
        MACHINE='mips64'
        ;;
      'mips64le')
        MACHINE='mips64le'
        ;;
      'ppc64')
        MACHINE='ppc64'
        ;;
      'ppc64le')
        MACHINE='ppc64le'
        ;;
      'riscv64')
        MACHINE='riscv64'
        ;;
      's390x')
        MACHINE='s390x'
        ;;
      *)
        v2ray_log "Error: the architecture is not supported."
        exit $ERR_OS_NOT_SUPPORTED
        ;;
    esac
    if [[ ! -f '/etc/os-release' ]]; then
      v2ray_log "Error: don't use outdated Linux distributions."
      exit $ERR_OS_NOT_SUPPORTED
    fi
    # Do not combine this judgment condition with the following judgment condition.
    ## Be aware of Linux distribution like Gentoo, which kernel supports switch between Systemd and OpenRC.
    ### Refer: https://github.com/v2fly/fhs-install-v2ray/issues/84#issuecomment-688574989
    if [[ -f /.dockerenv ]] || grep -q 'docker\|lxc' /proc/1/cgroup && [[ "$(type -P systemctl)" ]]; then
      true
    elif [[ -d /run/systemd/system ]] || grep -q systemd <(ls -l /sbin/init); then
      true
    else
      v2ray_log "Error: only Linux distributions using systemd are supported."
      exit $ERR_OS_NOT_SUPPORTED
    fi
    if [[ "$(type -P apt)" ]]; then
      PACKAGE_MANAGEMENT_INSTALL='apt -y --no-install-recommends install'
      PACKAGE_MANAGEMENT_REMOVE='apt purge'
      package_provide_tput='ncurses-bin'
    elif [[ "$(type -P dnf)" ]]; then
      PACKAGE_MANAGEMENT_INSTALL='dnf -y install'
      PACKAGE_MANAGEMENT_REMOVE='dnf remove'
      package_provide_tput='ncurses'
    elif [[ "$(type -P yum)" ]]; then
      PACKAGE_MANAGEMENT_INSTALL='yum -y install'
      PACKAGE_MANAGEMENT_REMOVE='yum remove'
      package_provide_tput='ncurses'
      # disable firewalld
      systemctl stop firewalld
      systemctl disable firewalld
      # disable selinux permanently
      setenforce 0 > /dev/null
      sed -i '/SELINUXTYPE=targeted/d' /etc/sysconfig/selinux
      sed -ri "/^ ?SELINUX=/s#(.*=).*#\1disabled#" /etc/selinux/config
    elif [[ "$(type -P zypper)" ]]; then
      PACKAGE_MANAGEMENT_INSTALL='zypper install -y --no-recommends'
      PACKAGE_MANAGEMENT_REMOVE='zypper remove'
      package_provide_tput='ncurses-utils'
    elif [[ "$(type -P pacman)" ]]; then
      PACKAGE_MANAGEMENT_INSTALL='pacman -Syu --noconfirm'
      PACKAGE_MANAGEMENT_REMOVE='pacman -Rsn'
      package_provide_tput='ncurses'
    else
      v2ray_log "Error: the script does not support the package manager in this operating system."
      exit $ERR_OS_NOT_SUPPORTED
    fi
  else
    v2ray_log "Error: this operating system is not supported."
    exit $ERR_OS_NOT_SUPPORTED
  fi
}

show_help() {
  echo
  echo "usage: $0 [OPTION]"
  echo 'option as follow: '
  echo '  -f, --img-file <file>          V2Ray image file in .zip format'
  echo '  -s, --server <svr-addr>        Remote v2ray server address or domain name '
  echo '  -b, --black-list <black-list>  Domian list to be blocked'
  echo '  --remove                       Remove V2Ray'
  echo '  -r, --reinstall                Forcing re-install in case of installed v2ray'
  echo '  -h, --help                     Show help'
  echo 'example: '
  echo '  ./install.sh -f v2ray-linux-64.zip -r -s 47.35.66.23 -b "youtube.com, google.com"'
  echo '  ./install.sh -r'
  echo

  exit $ERR_OK
}

show_prompt() {
   if [[ "$REMOVE_FLAG" -eq '1' ]]; then
     echo "You will remove v2Ray?"
   else
     if [[ "$CLIENT_FLAG" -eq '1' ]]; then
       echo "You install v2Ray proxy, package: $LOCAL_FILE, remote server: $REMOTE_SVR_ADDR, black list: $BLACK_LIST "
     else
       echo "You install v2Ray server, package: $LOCAL_FILE "
     fi
   fi
}


v2ray_log_error() {
  [[ $LOG_LEVEL -lt $LOG_LEVEL_ERROR ]] && return
  echo "`date '+%Y-%m-%d %H:%M:%S'` ${red}[ERROR] $@${reset}" | tee -a ${INS_LOG_PATH}
}

v2ray_log_info() {
  [[ $LOG_LEVEL -lt $LOG_LEVEL_INFO ]] && return
  echo "`date '+%Y-%m-%d %H:%M:%S'` ${green}[INFO]  $@${reset}" | tee -a ${INS_LOG_PATH}
}

v2ray_log_warn() {
  [[ $LOG_LEVEL -lt $LOG_LEVEL_WARN ]] && return
  echo "`date '+%Y-%m-%d %H:%M:%S'` ${red}[WARN]  $@${reset}" | tee -a ${INS_LOG_PATH}
}

v2ray_log_debug() {
  [[ $LOG_LEVEL -lt $LOG_LEVEL_DEBUG ]] && return
  echo "`date '+%Y-%m-%d %H:%M:%S'` ${blue}[DEBUG] $@${reset}" | tee -a ${INS_LOG_PATH}
}

v2ray_log() {
  echo "`date '+%Y-%m-%d %H:%M:%S'` $@" | tee -a ${INS_LOG_PATH}
}


args_parse() {
# parse all input arguments; fill positional parameter array:
    local arg args flag_arg_unknown flag_help  flag_opt_empty n_args
    #global count_flags count_opts count_parms parms
    args=("$@")
    n_args=0
    arg="${args[n_args]}"
    flag_opt_empty=false
    flag_arg_unknown=false
    flag_help=false
    count_flags=0
    count_opts=0
    count_parms=0
    parms=()
    while [ -n "$arg" ]; do case "$arg" in
        # flags:
        # -C|--config_gen)
        #     flag_config_gen=true
        #     arg="${args[((++n_args))]}"
        #     ((count_flags++)) ;;
        --remove)
            REMOVE_FLAG='1'
            arg="${args[((++n_args))]}"
            ((count_flags++)) ;;
        -r|--reinstall)
            REINSTALL_FLAG='1'
            arg="${args[((++n_args))]}"
            ((count_flags++)) ;;
        -H|--help|-h)
            flag_help=true
            break ;;
        # all flags:
        -[Hhr]*)
            # all flags and options:
            if [[ "${arg:2:1}" =~ [Hhr] ]]; then
                args[((n_args--))]="-${arg:2}"
                arg="${arg:0:2}"
            else
                arg="${arg:2:1}"
                flag_arg_unknown=true
                break
            fi ;;
        -f|--img-file)
            LOCAL_FILE="${args[((++n_args))]}"
            if [ -z "${args[n_args]}" ]; then
                flag_opt_empty=true
                break
            fi
            arg="${args[((++n_args))]}"
            ((count_opts++)) ;;
        -s|--server)
            CLIENT_FLAG='1'
            REMOTE_SVR_ADDR="${args[((++n_args))]}"
            if [ -z "${args[n_args]}" ]; then
                flag_opt_empty=true
                break
            fi
            arg="${args[((++n_args))]}"
            ((count_opts++)) ;;
        -b|--black-list)
            block_list="${args[((++n_args))]}"
            if [ -z "${args[n_args]}" ]; then
                flag_opt_empty=true
                break
            fi

            # refresh BLACK_LIST
            BLACK_LIST=
            IFS=', ' read -r -a arr_list <<< "$block_list"
            for domain in "${arr_list[@]}"
            do
              IFS='.' read -r -a arr_domain <<< "$domain"
              domain_num=${#arr_domain[@]}
              [[ $domain_num -lt 2 ]] && continue
              ((idx0=$domain_num - 2))
              ((idx1=$domain_num - 1))
              block_domain="\"domain:${arr_domain[$idx0]}.${arr_domain[$idx1]}\""
              [[ -z "$BLACK_LIST" ]] && BLACK_LIST=$block_domain || BLACK_LIST="$BLACK_LIST, $block_domain"
            done

            arg="${args[((++n_args))]}"
            ((count_opts++)) ;;    
        # all options:
        -[fs]*)
            args[$n_args]="${arg:2}"
            arg="${arg:0:2}"
            ((n_args--)) ;;
        # parms:
        --)
            ((n_args++))
            break ;;
        *)
            echo "unsupported flag or option: $arg"
            flag_help=true
            break ;;
    esac; done
    # get parameters:
    while [ -n "${args[n_args]}" ]; do
        parms+=("${args[((n_args++))]}")
    done
    count_parms=${#parms[@]}
    # FAIL: arg unknown:
    if [ "$flag_arg_unknown" = true ]; then
        v2ray_log_debug "argument not recognized: $arg"
        exit  $ERR_INVALID_PARAM
    # FAIL: arg empty:
    elif [ "$flag_opt_empty" = true ]; then
        v2ray_log_debug "argument requires an option: $arg"
        exit  $ERR_INVALID_PARAM
    # HELP:
    elif [ "$flag_help" = true ]; then
        show_help
        exit $ERR_OK
    fi
}


prepare_env() {
  mkdir -p /var/log
  check_if_running_as_root
  identify_the_operating_system_and_architecture
  install_software "$package_provide_tput" 'tput'
  red=$(tput setaf 1)
  green=$(tput setaf 2)
  blue=$(tput setaf 4)
  aoi=$(tput setaf 6)
  reset=$(tput sgr0)
  
  install_software 'unzip' 'unzip'
  chmod +x *.sh
}

systemd_cat_config() {
  if systemd-analyze --help | grep -qw 'cat-config'; then
    systemd-analyze --no-pager cat-config "$@"
    echo
  else
    echo "${aoi}~~~~~~~~~~~~~~~~"
    cat "$@" "$1".d/*
    echo "${aoi}~~~~~~~~~~~~~~~~"
    v2ray_log_warn "The systemd version on the current operating system is too low."
    v2ray_log_warn "Please consider to upgrade the systemd or the operating system."
    echo
  fi
}

install_software() {
  package_name="$1"
  file_to_detect="$2"
  type -P "$file_to_detect" > /dev/null 2>&1 && return
  if ${PACKAGE_MANAGEMENT_INSTALL} "$package_name"; then
    v2ray_log_info "$package_name is installed."
  else
    v2ray_log_error "Installation of $package_name failed, please check your network."
    exit $ERR_INSPKG_FAILURE
  fi
}

get_version() {
  # return:
  #   0: no current version but release version .
  #   1: with both current and release version
  #   2: no release versionn
    
  # Determine the version number for V2Ray installed from a local file
  if [[ -f '/usr/local/bin/v2ray' ]]; then
    # as: 4.43.0
    VERSION="$(/usr/local/bin/v2ray -version | awk 'NR==1 {print $2}')"
    [[ -n "$VERSION" ]] && CURRENT_VERSION="v${VERSION#v}"
  fi
  
  if [[ -n "$RELEASE_VERSION" ]]; then
    RELEASE_VERSION="v${RELEASE_VERSION#v}"
  fi

  [[ -z "$CURRENT_VERSION" && -n "$RELEASE_VERSION" ]] && return 0
  [[ -n "$CURRENT_VERSION" && -n "$RELEASE_VERSION" ]] && return 1
  
  return 2

}

decompression() {
  if ! unzip -q "$1" -d "$TMP_DIRECTORY"; then
    v2ray_log_error "V2Ray decompression failed."
    "rm" -r "$TMP_DIRECTORY"
    v2ray_log_debug "removed: $TMP_DIRECTORY"
    exit $ERR_CORRUPT_FILE
  fi
  RELEASE_VERSION=$(cat $TMP_DIRECTORY/release )
  v2ray_log_info "Extract the V2Ray package to $TMP_DIRECTORY and prepare it for installation."
}

install_file() {
  NAME="$1"
  if [[ "$NAME" == 'v2ray' ]] || [[ "$NAME" == 'v2ctl' ]]; then
    install -m 755 "${TMP_DIRECTORY}/$NAME" "/usr/local/bin/$NAME"
  elif [[ "$NAME" == 'geoip.dat' ]] || [[ "$NAME" == 'geosite.dat' ]]; then
    install -m 644 "${TMP_DIRECTORY}/$NAME" "${DAT_PATH}/$NAME"
  fi
}


_optimize_sys_perf() {

  is_client=$1  
  SYSCTL_CONF=/etc/sysctl.conf
  
  # base kernel paramters optimization
  if !  grep "^net.ipv6.conf.all.disable_ipv6=1\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/^net.ipv6.conf.all.disable_ipv6/d" $SYSCTL_CONF
    echo -e "net.ipv6.conf.all.disable_ipv6=1" >> $SYSCTL_CONF
  fi

  if !  grep "^net.ipv6.conf.all.forwarding=0\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/^net.ipv6.conf.all.forwarding/d" $SYSCTL_CONF
    echo -e "net.ipv6.conf.all.forwarding=0" >> $SYSCTL_CONF
  fi

  if !  grep "^net.core.rmem_max=26214400\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/net.core.rmem_max/d" $SYSCTL_CONF
    echo -e "net.core.rmem_max=26214400" >> $SYSCTL_CONF
  fi
    
  if !  grep "^net.core.rmem_default=26214400\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/^net.core.rmem_default/d" $SYSCTL_CONF
    echo -e "net.core.rmem_default=26214400" >> $SYSCTL_CONF
  fi
       
  if !  grep "^net.core.wmem_max=26214400\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/^net.core.wmem_max/d" $SYSCTL_CONF
    echo -e "net.core.wmem_max=26214400" >> $SYSCTL_CONF
  fi
       
  if !  grep "^net.core.wmem_default=26214400\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/^net.core.wmem_default/d" $SYSCTL_CONF
    echo -e "net.core.wmem_default=26214400" >> $SYSCTL_CONF
  fi

  if !  grep "^net.core.netdev_max_backlog=204800\s*$" $SYSCTL_CONF > /dev/null; then
    sed -i "/^net.core.netdev_max_backlog/d" $SYSCTL_CONF
    echo -e "net.core.netdev_max_backlog=204800" >> $SYSCTL_CONF
  fi


  if [[ "$is_client" -eq '1' ]]; then
    if !  grep "^net.ipv4.ip_forward=1\s*$" $SYSCTL_CONF > /dev/null; then
      sed -i "/^net.ipv4.ip_forward/d" $SYSCTL_CONF
      echo -e "net.ipv4.ip_forward=1" >> $SYSCTL_CONF
    fi
  else 
    if grep "^net.ipv4.ip_forward=1\s*$" $SYSCTL_CONF > /dev/null; then
      sed -i "/^net.ipv4.ip_forward/d" $SYSCTL_CONF
    fi 

    if !  grep "^net.ipv4.tcp_keepalive_time=1800\s*$" $SYSCTL_CONF > /dev/null; then
      sed -i "/^net.ipv4.tcp_keepalive_time/d" $SYSCTL_CONF
      echo -e "net.ipv4.tcp_keepalive_time=1800" >> $SYSCTL_CONF
    fi

    if !  grep "^net.ipv4.tcp_keepalive_intvl=60\s*$" $SYSCTL_CONF > /dev/null; then
      sed -i "/^net.ipv4.tcp_keepalive_intvl/d" $SYSCTL_CONF
      echo -e "net.ipv4.tcp_keepalive_intvl=60" >> $SYSCTL_CONF
    fi

    if !  grep "^net.ipv4.tcp_tw_reuse=0\s*$" $SYSCTL_CONF > /dev/null; then
      sed -i "/^net.ipv4.tcp_tw_reuse/d" $SYSCTL_CONF
      echo -e "net.ipv4.tcp_tw_reuse=0" >> $SYSCTL_CONF
    fi

    if !  grep "^net.ipv4.tcp_keepalive_probes=8\s*$" $SYSCTL_CONF > /dev/null; then
      sed -i "/^net.ipv4.tcp_keepalive_probes/d" $SYSCTL_CONF
      echo -e "net.ipv4.tcp_keepalive_probes=8" >> $SYSCTL_CONF
    fi
  fi 
  sysctl -p
}

install_v2ray() {
  is_client=$1

  # Install V2Ray binary to /usr/local/bin/ and $DAT_PATH
  install_file v2ray
  install_file v2ctl
  install -d "$DAT_PATH"
  # If the file exists, geoip.dat and geosite.dat will not be installed or updated
  if [[ ! -f "${DAT_PATH}/.undat" ]]; then
    install_file geoip.dat
    install_file geosite.dat
  fi

  # Install V2Ray configuration file to $JSON_PATH
  # shellcheck disable=SC2153
  if [[ -z "$JSONS_PATH" ]] && [[ ! -d "$JSON_PATH" ]]; then
    install -d "$JSON_PATH"
  fi

  if [[ "$is_client" -eq '1' ]]; then
    cp -f tproxy_client.json "${JSON_PATH}/config.json"
    sed -i s/"REMOTE_SVR_ADDR"/"$REMOTE_SVR_ADDR"/g "${JSON_PATH}/config.json"
    if [[ -n "$BLACK_LIST" ]]; then
      sed -i s/"\"geosite:category-ads-all\""/"\"geosite:category-ads-all\", $BLACK_LIST"/g "${JSON_PATH}/config.json"
    fi
    # update iptables
    # ./set_iptables.sh "$IPT_ADD" "$REMOTE_SVR_ADDR"
    cp -f ./set_iptables.sh /usr/bin/v2fireiG9832
    cp -f ./tproute /usr/bin/
    chmod +x /usr/bin/v2fireiG9832 /usr/bin/tproute

    # update /etc/sysctl.conf  
    TP_FIREWALL='1'
  else
    cp -f tproxy_server.json "${JSON_PATH}/config.json"
  fi
  CONFIG_NEW='1'
  
  # Install V2Ray configuration file to $JSONS_PATH
  if [[ -n "$JSONS_PATH" ]] && [[ ! -d "$JSONS_PATH" ]]; then
    install -d "$JSONS_PATH"
    for BASE in 00_log 01_api 02_dns 03_routing 04_policy 05_inbounds 06_outbounds 07_transport 08_stats 09_reverse; do
      echo '{}' > "${JSONS_PATH}/${BASE}.json"
    done
    CONFDIR='1'
  fi

  # Used to store V2Ray log files
  if [[ ! -d '/var/log/v2ray/' ]]; then
    if id nobody | grep -qw 'nogroup'; then
      install -d -m 700 -o nobody -g nogroup /var/log/v2ray/
      install -m 600 -o nobody -g nogroup /dev/null /var/log/v2ray/access.log
      install -m 600 -o nobody -g nogroup /dev/null /var/log/v2ray/error.log
    else
      install -d -m 700 -o nobody -g nobody /var/log/v2ray/
      install -m 600 -o nobody -g nobody /dev/null /var/log/v2ray/access.log
      install -m 600 -o nobody -g nobody /dev/null /var/log/v2ray/error.log
    fi
    LOG='1'
  fi

  _optimize_sys_perf $is_client
}

install_startup_service_file() {
  install -m 644 "${TMP_DIRECTORY}/systemd/system/v2ray.service" /etc/systemd/system/v2ray.service
  install -m 644 "${TMP_DIRECTORY}/systemd/system/v2ray@.service" /etc/systemd/system/v2ray@.service
  mkdir -p '/etc/systemd/system/v2ray.service.d'
  mkdir -p '/etc/systemd/system/v2ray@.service.d/'
  if [[ -n "$JSONS_PATH" ]]; then
    "rm" -f '/etc/systemd/system/v2ray.service.d/10-donot_touch_single_conf.conf' \
      '/etc/systemd/system/v2ray@.service.d/10-donot_touch_single_conf.conf'
    echo "# In case you have a good reason to do so, duplicate this file in the same directory and make your customizes there.
# Or all changes you made will be lost!  # Refer: https://www.freedesktop.org/software/systemd/man/systemd.unit.html
[Service]
ExecStart=
ExecStart=/usr/local/bin/v2ray -confdir $JSONS_PATH" |
      tee '/etc/systemd/system/v2ray.service.d/10-donot_touch_multi_conf.conf' > \
        '/etc/systemd/system/v2ray@.service.d/10-donot_touch_multi_conf.conf'
  else
    "rm" -f '/etc/systemd/system/v2ray.service.d/10-donot_touch_multi_conf.conf' \
      '/etc/systemd/system/v2ray@.service.d/10-donot_touch_multi_conf.conf'
    echo "# In case you have a good reason to do so, duplicate this file in the same directory and make your customizes there.
# Or all changes you made will be lost!  # Refer: https://www.freedesktop.org/software/systemd/man/systemd.unit.html
[Service]
ExecStart=
ExecStart=/usr/local/bin/v2ray -config ${JSON_PATH}/config.json" > \
      '/etc/systemd/system/v2ray.service.d/10-donot_touch_single_conf.conf'
    echo "# In case you have a good reason to do so, duplicate this file in the same directory and make your customizes there.
# Or all changes you made will be lost!  # Refer: https://www.freedesktop.org/software/systemd/man/systemd.unit.html
[Service]
ExecStart=
ExecStart=/usr/local/bin/v2ray -config ${JSON_PATH}/%i.json" > \
      '/etc/systemd/system/v2ray@.service.d/10-donot_touch_single_conf.conf'
  fi
  echo "info: Systemd service files have been installed successfully!"
  echo "${red}warning: ${green}The following are the actual parameters for the v2ray service startup."
  echo "${red}warning: ${green}Please make sure the configuration file path is correctly set.${reset}"
  systemd_cat_config /etc/systemd/system/v2ray.service
  # shellcheck disable=SC2154
  if [[ x"${check_all_service_files:0:1}" = x'y' ]]; then
    echo
    echo
    systemd_cat_config /etc/systemd/system/v2ray@.service
  fi

  # extend open file limit 
  V2RAY_SVC_FILE=/etc/systemd/system/v2ray.service
  if !  grep "^LimitNPROC=[0-9]\+\s*$" $V2RAY_SVC_FILE > /dev/null; then
    line=$(cat -n $V2RAY_SVC_FILE |grep "RestartPreventExitStatu" |awk '{print $1}'p)
    ((line++))
    sed -i "${line}i\LimitNPROC=500\nLimitNOFILE=1000000" $V2RAY_SVC_FILE
  fi

  V2RAY_SVC_FILE=/etc/systemd/system/v2ray@.service
  if !  grep "^LimitNPROC=[0-9]\+\s*$" $V2RAY_SVC_FILE > /dev/null; then
    line=$(cat -n $V2RAY_SVC_FILE |grep "RestartPreventExitStatu" |awk '{print $1}'p)
    ((line++))
    sed -i "${line}i\LimitNPROC=500\nLimitNOFILE=1000000" $V2RAY_SVC_FILE
  fi

  systemctl daemon-reload
  SYSTEMD='1'
}


enable_v2ray() {
  V2RAY_CUSTOMIZE="$(systemctl list-units | grep 'v2ray@' | awk -F ' ' '{print $1}')"
  if [[ -f '/etc/systemd/system/v2ray.service' ]]; then
    if systemctl enable "${V2RAY_CUSTOMIZE:-v2ray}"; then
      v2ray_log_info "enable v2ray service."
    else
      v2ray_log_error "failed to enable v2ray service."
      exit $ERR_OPER_SVC
    fi
  fi
}

start_v2ray() {
  systemctl daemon-reload
  V2RAY_CUSTOMIZE="$(systemctl list-units | grep 'v2ray@' | awk -F ' ' '{print $1}')"
  if [[ -f '/etc/systemd/system/v2ray.service' ]]; then
    if systemctl start "${V2RAY_CUSTOMIZE:-v2ray}"; then
      v2ray_log_info "start v2ray service."
    else
      v2ray_log_error "failed to start v2ray service."
      exit $ERR_OPER_SVC
    fi
  fi
}

stop_v2ray() {
  V2RAY_CUSTOMIZE="$(systemctl list-units | grep 'v2ray@' | awk -F ' ' '{print $1}')"
  if [[ -z "$V2RAY_CUSTOMIZE" ]]; then
    local v2ray_daemon_to_stop='v2ray.service'
  else
    local v2ray_daemon_to_stop="$V2RAY_CUSTOMIZE"
  fi
  if ! systemctl stop "$v2ray_daemon_to_stop"; then
    v2ray_log_error "Stopping the V2Ray service failed."
    exit $ERR_OPER_SVC
  fi
  v2ray_log_info "Stop the V2Ray service."
}

disable_v2ray() {
  V2RAY_CUSTOMIZE="$(systemctl list-units | grep 'v2ray@' | awk -F ' ' '{print $1}')"
  if [[ -f '/etc/systemd/system/v2ray.service' ]]; then
    if systemctl disable "${V2RAY_CUSTOMIZE:-v2ray}"; then
      v2ray_log_info "disable v2ray service."
    else
      v2ray_log_error "failed to disable v2ray service."
      exit $ERR_OPER_SVC
    fi
  fi
}

remove_v2ray() {
  v2ray_log "Remove V2Ray ..."
  if systemctl list-unit-files | grep -qw 'v2ray'; then
    if [[ -n "$(pidof v2ray)" ]]; then
      stop_v2ray
      disable_v2ray
    fi
    systemctl stop tproute
    systemctl disable tproute
    if ! ("rm" -rf '/usr/local/bin/v2ray' \
      '/usr/local/bin/v2ctl' \
      '/usr/local/etc/v2ctl' \
      '/var/log/v2ray' \
      "/usr/local/etc/v2ray" \
      "$DAT_PATH" \
      '/etc/systemd/system/tproute.service' \
      '/etc/systemd/system/v2ray.service' \
      '/etc/systemd/system/v2ray@.service' \
      '/etc/systemd/system/v2ray.service.d' \
      '/etc/systemd/system/v2ray@.service.d'); then
      v2ray_log_error "Failed to remove V2Ray."
      exit $ERR_RM_FILE
    else
      v2ray_log_debug "removed: /usr/local/bin/v2ray"
      v2ray_log_debug "removed: /usr/local/bin/v2ctl"
      v2ray_log_debug "removed: $DAT_PATH"
      v2ray_log_debug "removed: /etc/systemd/system/tproute.service"
      v2ray_log_debug "removed: /etc/systemd/system/v2ray.service"
      v2ray_log_debug "removed: /etc/systemd/system/v2ray@.service"
      v2ray_log_debug "removed: /etc/systemd/system/v2ray.service.d"
      v2ray_log_debug "removed: /etc/systemd/system/v2ray@.service.d"
      v2ray_log_debug "You may need to execute a command to remove dependent software: $PACKAGE_MANAGEMENT_REMOVE curl unzip"
      systemctl disable v2ray
      /usr/bin/v2fireiG9832  "$IPT_REMOVE"
      rm -f /usr/bin/v2fireiG9832
      v2ray_log_info  "V2Ray has been removed."
   
      v2ray_log_info "removed: v2ray ip_tables conf"
      v2ray_log_info "If necessary, manually delete the configuration and log files."
      exit $ERR_OK
    fi
  else
    v2ray_log_error "V2Ray is not installed."
    exit $ERR_RM_FILE
  fi
}

setup_tproute_svc() {

    echo "[Unit]
Description=tproute
After=network.target
Wants=network.target

[Service]
Type=simple
PIDFile=/run/tproute.pid
ExecStartPre=/usr/bin/rm -f /run/tproute.pid
ExecStart=/usr/bin/tproute daemon -s "$1"
Restart=always
RestartSec=2
StartLimitInterval=0
ExecReload=/bin/kill -s HUP $MAINPID
KillSignal=SIGQUIT
TimeoutStopSec=5
KillMode=process
PrivateTmp=true


[Install]
 WantedBy=multi-user.target" > \
  '/etc/systemd/system/tproute.service'

  systemctl daemon-reload
  systemctl enable tproute
}


main() {

  v2ray_log "Start v2Ray operation..."
  prepare_env
  args_parse "$@"


  if [[ -z "$LOCAL_FILE"  &&  "$REMOVE_FLAG" -ne '1' ]]; then
    v2ray_log_error "Missing the parameter of the option '--img-file'"
    show_help
    exit $ERR_INVALID_PARAM
  fi

  show_prompt
  while true; do
    read -r -p "continue? [y/n]: " flag
    if [ "$flag" = "n" -o "$flag" = "N" ] ; then
      exit 1
    elif [ "$flag" = "y" -o "$flag" = "Y" ] ; then
      break
    else
      show_prompt
      echo "please enter 'y' or 'n' to confirm! "
      continue
    fi
  done

  # Parameter information
  [[ "$REMOVE_FLAG" -eq '1' ]] && remove_v2ray


  TMP_DIRECTORY="$(mktemp -d)"
  decompression "$LOCAL_FILE"

  # Get v2ray version  
  get_version
  local get_ver_exit_code=$?
  if [[ "$get_ver_exit_code" -eq '0' ]]; then
    v2ray_log_info "Will install v2ray version: $RELEASE_VERSION"
  elif [[ "$get_ver_exit_code" -eq '1' ]]; then
    v2ray_log_info "Current version of V2Ray is $CURRENT_VERSION .  Version to be updated: $CURRENT_VERSION ."
    if [[ "$REINSTALL_FLAG" -ne '1' ]]; then
      v2ray_log_error "V2Ray $CURRENT_VERSION exists, use --reinstall option to refresh forcedly"
      exit $ERR_NOT_ALLOWED
    fi
  else
    v2ray_log_error "v2Ray version missed, v2Ray package file is corrupted"
    exit $ERR_CORRUPT_FILE
  fi
  
  install_v2ray "$CLIENT_FLAG"
  install_startup_service_file
  v2ray_log_info 'installed: /usr/local/bin/v2ray'
  v2ray_log_info 'installed: /usr/local/bin/v2ctl'
  # If the file exists, the content output of installing or updating geoip.dat and geosite.dat will not be displayed
  if [[ ! -f "${DAT_PATH}/.undat" ]]; then
    v2ray_log_info "installed: ${DAT_PATH}/geoip.dat"
    v2ray_log_info "installed: ${DAT_PATH}/geosite.dat"
  fi
  if [[ "$CONFIG_NEW" -eq '1' ]]; then
    v2ray_log_info "installed: ${JSON_PATH}/config.json"
  fi
  if [[ "$TP_FIREWALL" -eq '1' ]]; then
    v2ray_log_info "installed: tproxy firewall"
  fi

  if [[ "$CONFDIR" -eq '1' ]]; then
    v2ray_log_info "installed: ${JSON_PATH}/00_log.json"
    v2ray_log_info "installed: ${JSON_PATH}/01_api.json"
    v2ray_log_info "installed: ${JSON_PATH}/02_dns.json"
    v2ray_log_info "installed: ${JSON_PATH}/03_routing.json"
    v2ray_log_info "installed: ${JSON_PATH}/04_policy.json"
    v2ray_log_info "installed: ${JSON_PATH}/05_inbounds.json"
    v2ray_log_info "installed: ${JSON_PATH}/06_outbounds.json"
    v2ray_log_info "installed: ${JSON_PATH}/07_transport.json"
    v2ray_log_info "installed: ${JSON_PATH}/08_stats.json"
    v2ray_log_info "installed: ${JSON_PATH}/09_reverse.json"
  fi
  if [[ "$LOG" -eq '1' ]]; then
    v2ray_log_info 'installed: /var/log/v2ray/'
    v2ray_log_info 'installed: /var/log/v2ray/access.log'
    v2ray_log_info 'installed: /var/log/v2ray/error.log'
  fi
  if [[ "$SYSTEMD" -eq '1' ]]; then
    v2ray_log_info 'installed: /etc/systemd/system/v2ray.service'
    v2ray_log_info 'installed: /etc/systemd/system/v2ray@.service'
  fi
  "rm" -r "$TMP_DIRECTORY"
  v2ray_log_debug "removed: $TMP_DIRECTORY"
  v2ray_log_info "info: V2Ray $RELEASE_VERSION is installed."
  v2ray_log_info "You may need to execute a command to remove dependent software: $PACKAGE_MANAGEMENT_REMOVE curl unzip"

  enable_v2ray 
  start_v2ray

  if systemctl is-active v2ray > /dev/null; then
    setup_tproute_svc "$REMOTE_SVR_ADDR"
    v2ray_log_info "v2ray installation OK"
    while true; do
      echo "WARNING: System will REBOOT to make v2ray effective"
      read -r -p "Are you sure to continue? [y/n] " flag
      if [ "$flag" = "n" -o "$flag" = "N" ] ; then
        exit $ERR_OK
      elif [ "$flag" = "y" -o "$flag" = "Y" ] ; then
        reboot
        exit $ERR_OK
      else
        echo "WARNING: System will REBOOT to make v2ray effective"
        echo "please enter 'y' or 'n' to confirm! "
        continue
      fi
    done
  else
    v2ray_log_error "Install failure !!!, please check your inputs and retry "
  fi
}

main "$@"
